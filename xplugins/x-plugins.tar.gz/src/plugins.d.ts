declare module globalThis {
  interface String {
    secret: (length?: number) => this;
  }
}
declare module "x-plugins" {
  /**Send Notification */
  declare const $xEmit: (key: string, ...arg: any[]) => void;
  /** Spy Notification */
  declare const $xOn: (key: string, callback: (...arg: any[]) => void) => void;
  /** Disable Listening Notification */
  declare const $xOff: (
    key: string,
    callback?: (...arg: any[]) => void
  ) => void;
  /** random character */
  declare const RandomString: (length = 32) => string;
  /** 0.1 second timer */
  declare const AddListenAction: (
    call: (time: number) => boolean | Promise<boolean>
  ) => void;
  /** Waiting Time */
  declare const WaitTime: (time = 2000) => Promise<any>;
  /**  Waiting for feedback */
  declare const WaitContinue: (callback: () => boolean) => Promise<null>;
  /** json parsing */
  declare const JSONParse: (value) => object | null;
  /** Getting the right value  */
  declare const Clamp: (value: number, min: number, max: number) => number;
  /** Determine if it is empty */
  declare const IsEmpty: (value) => boolean;
  declare const Copy: (text) => void;
  /** String Coding */
  declare const encodeBase: (value: string) => string;
  /** String Decoding  */
  declare const decodeBase: (value: string) => string;

  declare interface XWorkerType {
    postMessage: (data: { cmd: string; data: any }) => void;
    onmessage: (e: { data: { cmd: string; data: any } }) => void;
    terminate: () => void;
  }
  /** Decorator listens to worker messages */
  declare function OnMessage(cmd: string): any;
  /** Set the decorator to enable monitoring of worker messages. */
  declare function runMessage(target: Object, worker: XWorkerType): void;
  /** Decorator Monitor Notification Messages */
  declare function OnNotification(name: string): any;
  /** Set Decorator to listen to notification messages  */
  declare function runNotification(target: Object): void;
  /** Turn off the decorator to listen to notification messages */
  declare function stopNotfication(target: Object): void;
  /** Used to intercept method execution Decorator use */
  declare function RequestProxy(callback: () => boolean);
}

declare module "x-plugins/component" {
  declare const SignMessage: (
    callback: () => Promise<string | null>,
    type = false
  ) => Promise<string | null>;
}
