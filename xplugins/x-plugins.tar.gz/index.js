if (process.env.NODE_ENV==='development'){
    module.exports = require('x-plugins/lib/xplugins')
} else {
    module.exports = require('x-plugins/lib/xplugins.min')
}
